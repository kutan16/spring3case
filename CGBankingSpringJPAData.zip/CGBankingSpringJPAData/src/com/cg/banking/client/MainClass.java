package com.cg.banking.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

public class MainClass {

	public static void main(String[] args) throws InsufficientAmountException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidPinNumberException {		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("bankingBeans.xml");
		BankingServices services=(BankingServices) context.getBean("bankingServices");
		
		long accountNoTo,accountNoFrom,transferAmount;
		while(true) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. create Account");
		System.out.println("2. get account details");
		System.out.println("3. get every account details");
		System.out.println("4.deposit amount");
		System.out.println("5.withdraw amount");
		System.out.println("6.fund transfer ");
		System.out.println("7.exit");
		int n = sc.nextInt();
		switch(n) {
		case 1: 
			System.out.println("Enter the type of account you want to open: 'savings'/'current' ");
			String accountType=sc.next();
			System.out.println("Enter your current Balance");
			int initialBalance=sc.nextInt();
			try{
				Account account1 = services.openAccount(accountType,initialBalance);
				System.out.println(account1);
				System.out.println("account created");
			}
			catch(InvalidAmountException e) {
				e.printStackTrace();
				//System.out.println("invalid amount , please keep 500 minimum \n"+e);
			}
			catch(InvalidAccountTypeException e) {
				e.printStackTrace();
				//System.out.println("invalid account type \n"+e);
			}
			break;	
		case 2:
			System.out.println("Enter account no.");
			int accountNumber=sc.nextInt();
			
				System.out.println(services.getAccountDetails(accountNumber));
			
			break;
		case 3 : 
			System.out.println(services.getAllAccountDetails());
			break;	
		case 4:
			System.out.println("Enter 'accountNo' and 'amount to deposit' ");
			int accountNumber1=sc.nextInt();
			try {
				System.out.println(services.getAccountDetails((int) accountNumber1));
			} 
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			float amount1 = sc.nextFloat();
//			BankingServicesImpl account1 = new BankingServicesImpl();
			services.depositAmount((int) accountNumber1, amount1);
			break;	
		case 5:
//			BankingServicesImpl account2 = new BankingServicesImpl();
			System.out.println("Enter 'accountNo'");
			int accountNumber2=sc.nextInt();
			try {
				System.out.println(services.getAccountDetails((int) accountNumber2));
			} 
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			System.out.println("enter amount to withdraw");
			float amount2=sc.nextFloat();
			System.out.println("enter pin number");
			int pinNumber = sc.nextInt();
			try {
				services.withdrawAmount((int) accountNumber2, amount2, pinNumber);}
			catch(InvalidPinNumberException e) {
				e.printStackTrace();
			}
			break;	
		case 6:
			System.out.println("enter accNo to transfer money to :");
			accountNoTo=sc.nextLong();
			System.out.println("enter amount to transfer");
			transferAmount=sc.nextLong();
			System.out.println("enter accNo from where the money will be transferred : ");
			accountNoFrom=sc.nextLong();
			System.out.println("enter pin no to complete the transaction");
			pinNumber=sc.nextInt();
			try {
				System.out.println("fund transfer : \n"+services.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber));
				System.out.println("transaction done to : \n"+services.getAccountDetails((int) accountNoTo)+"\n"+"from \n"+services.getAccountDetails((int) accountNoFrom));
			}
			catch(BankingServicesDownException|AccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 7: System.exit(0);
		default: 
			System.out.println("enter correct choice");
		}
	}
}
}

